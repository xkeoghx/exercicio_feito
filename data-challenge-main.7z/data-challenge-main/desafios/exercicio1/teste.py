import json

with open('schema.json', 'r') as f:
    data = json.load(f)

event = {
    "eid": "3e628a05-7a4a-4bf3-8770-084c11601a12",
    "documentNumber": "42323235600",
    "name": "Joseph",
    "age": 32,
    "address": {
        "street": "St. Blue",
        "number": 3,
        "mailAddress": True
    }
}

def open_schema(input: dict):
    tipo_campo = {}
    data_type = input["properties"]

    for chave in data_type:
        if data_type[chave]["type"] == "object":
            tipo_campo = tipo_campo | open_schema(data_type[chave]) 
        else:
            tipo_campo[chave] = data_type[chave]["type"]
    
    return tipo_campo

def determina_tipo(input):
    if type(input) is str:
        return 'string'
    elif type(input) is int:
        return 'integer'
    elif type(input) is float:
        return 'numeric'
    elif type(input) is bool:
        return 'boolean'
    else:
        return 'object'


def detect_schema(input: dict):
    tipo_campo = {}

    for field in input:
        if determina_tipo(input[field]) == "object":
            tipo_campo = tipo_campo | detect_schema(input[field])             
        else:
            tipo_campo[field] = determina_tipo(input[field])

    
    return tipo_campo

print(detect_schema(event) == open_schema(data))
